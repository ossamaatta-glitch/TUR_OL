# Solution guide — Logic Course L01 Term Model To Identity

**Task ID:** `47eeb00f-1e2b-5d3a-ae79-bcf01fb8902f_overleaf_logic_course_l01_term_model_to_identity`  
**Startup profile:** `prompt_only`  
**Step budget:** `350`

## Objective

Action the unactioned review note on the Lecture 1 typeset notes. The lecture's review.md
records which step of the construction is classical, and where.

A reviewer left this note against the corollary labelled cor:gammastar in
lectures/01-completeness/lecture-notes.tex; nobody has actioned it:

Lindenbaum gets us the saturated complete consistent set; the model is still missing. Please
build it: the term model over closed terms (def:termmodel) with the value lemma (lem:val) and
the reduction of quantifiers to closed instances (prop:quant-termmodel); then the truth lemma
(lem:truth) by induction on length, each case citing the corresponding clause of the complete-
consistent-set proposition; then the congruence on closed terms for languages with identity
(def:approx, prop:approx with items ap1-ap5); and then the factored model (def:quotient,
prop:welldef, lem:val-factor) with the truth lemma for it (lem:truth-id). While you are in the
truth lemma, add the remark the review asked for (rem:classical) saying exactly which two steps
need RAA.

## Exact project changes

- `lectures/01-completeness/lecture-notes.tex` — modified (210 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
