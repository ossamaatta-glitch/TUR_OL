# Step-by-step solution — Logic Course L01 Term Model To Identity

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Open `lectures/01-completeness/lecture-notes.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/lectures/01-completeness/lecture-notes.tex`](source/lectures/01-completeness/lecture-notes.tex). Save the file.

## Finish

2. Compile the project and resolve any error caused by an incomplete edit.
3. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
