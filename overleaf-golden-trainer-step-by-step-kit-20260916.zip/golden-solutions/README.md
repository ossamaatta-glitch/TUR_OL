# Overleaf golden solution guides

Internal guides for designated golden trainers. Each guide describes the
verified delta from the seed project to the golden project. Perform the
edits manually through the platform's visible Overleaf UI; do not upload
the golden project or replay a machine-generated trajectory.

| Task | Startup profile | Changed files | Step-by-step guide |
| --- | --- | ---: | --- |
| `078a1547-e3e5-5e91-8842-64bfec032f19_overleaf_logic_course_l06_reducibility_to_fixed_point` | `prompt_only` | 1 | [Logic Course L06 Reducibility To Fixed Point](078a1547-e3e5-5e91-8842-64bfec032f19_overleaf_logic_course_l06_reducibility_to_fixed_point/STEP_BY_STEP.md) |
| `b7a032d2-74a3-5123-80f6-c59053f09cda_overleaf_logic_course_l14_numerals_to_fixpoint` | `prompt_only` | 1 | [Logic Course L14 Numerals To Fixpoint](b7a032d2-74a3-5123-80f6-c59053f09cda_overleaf_logic_course_l14_numerals_to_fixpoint/STEP_BY_STEP.md) |
| `47eeb00f-1e2b-5d3a-ae79-bcf01fb8902f_overleaf_logic_course_l01_term_model_to_identity` | `prompt_only` | 1 | [Logic Course L01 Term Model To Identity](47eeb00f-1e2b-5d3a-ae79-bcf01fb8902f_overleaf_logic_course_l01_term_model_to_identity/STEP_BY_STEP.md) |
| `806d699d-1b14-5f74-9809-02311817d71c_overleaf_cloudia_ai_portfolio` | `brief_in_documents` | 59 | [Cloudia Ai Portfolio](806d699d-1b14-5f74-9809-02311817d71c_overleaf_cloudia_ai_portfolio/STEP_BY_STEP.md) |
| `f252b249-cfec-540f-aef1-ad91e84e276d_overleaf_cloudia_security_portfolio` | `brief_in_documents` | 71 | [Cloudia Security Portfolio](f252b249-cfec-540f-aef1-ad91e84e276d_overleaf_cloudia_security_portfolio/STEP_BY_STEP.md) |
| `2fcc4fa2-7623-55ee-ad65-1bf484ecc546_overleaf_cloudia_iot_zenith_footprint` | `brief_in_documents` | 32 | [Cloudia Iot Zenith Footprint](2fcc4fa2-7623-55ee-ad65-1bf484ecc546_overleaf_cloudia_iot_zenith_footprint/STEP_BY_STEP.md) |
| `4cec0a01-5b65-58e9-b13f-bb1600d70d1d_overleaf_cloudia_media_standup` | `brief_in_documents` | 34 | [Cloudia Media Standup](4cec0a01-5b65-58e9-b13f-bb1600d70d1d_overleaf_cloudia_media_standup/STEP_BY_STEP.md) |
| `4f2321df-b12c-5d01-9bd5-1e5c808c9169_overleaf_cloudia_devtools_standup` | `brief_in_documents` | 35 | [Cloudia Devtools Standup](4f2321df-b12c-5d01-9bd5-1e5c808c9169_overleaf_cloudia_devtools_standup/STEP_BY_STEP.md) |
| `63ee5800-959b-5381-847f-448d4c295fd6_overleaf_cloudia_enduser_standup` | `brief_in_documents` | 16 | [Cloudia Enduser Standup](63ee5800-959b-5381-847f-448d4c295fd6_overleaf_cloudia_enduser_standup/STEP_BY_STEP.md) |
| `65237749-4997-5c14-9c09-f55cf2f4a22e_overleaf_cloudia_containers_standup` | `brief_open` | 23 | [Cloudia Containers Standup](65237749-4997-5c14-9c09-f55cf2f4a22e_overleaf_cloudia_containers_standup/STEP_BY_STEP.md) |
