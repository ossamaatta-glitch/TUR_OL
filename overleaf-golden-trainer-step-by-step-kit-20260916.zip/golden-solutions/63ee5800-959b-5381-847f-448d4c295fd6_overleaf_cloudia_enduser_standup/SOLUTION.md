# Solution guide — Cloudia Enduser Standup

**Task ID:** `63ee5800-959b-5381-847f-448d4c295fd6_overleaf_cloudia_enduser_standup`  
**Startup profile:** `brief_in_documents`  
**Step budget:** `350`

## Objective

Category 18 is only four services in data/services.csv -- desktops, application streaming, the
managed browser and the thin clients -- so it is a short one.

What has to land:

- the root deck inputs enduser after migration and above the appendix;
- the opener carries number 18, the registry name and accent, and four services;
- the virtual-desktop page exists, keyed from the registry;
- the thin-client page carries the registry's scope rather than the template default: the box
  sits on someone's desk, so it is not a regional service;
- all four pages are inputted, the browser page a colleague pushes included.

## Exact project changes

- `art/categories/enduser.pdf` — added (binary; compare hashes)
- `art/categories/enduser.svg` — added (34 patch lines)
- `art/glyphs/appwindow.pdf` — added (binary; compare hashes)
- `art/glyphs/appwindow.svg` — added (9 patch lines)
- `art/glyphs/browserlock.pdf` — added (binary; compare hashes)
- `art/glyphs/browserlock.svg` — added (9 patch lines)
- `art/glyphs/thinclient.pdf` — added (binary; compare hashes)
- `art/glyphs/thinclient.svg` — added (9 patch lines)
- `art/glyphs/vdi.pdf` — added (binary; compare hashes)
- `art/glyphs/vdi.svg` — added (8 patch lines)
- `catalog/enduser/alcove.tex` — added (81 patch lines)
- `catalog/enduser/doorstep.tex` — added (78 patch lines)
- `catalog/enduser/enduser.tex` — added (39 patch lines)
- `catalog/enduser/transom.tex` — added (82 patch lines)
- `catalog/enduser/vestibule.tex` — added (78 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
