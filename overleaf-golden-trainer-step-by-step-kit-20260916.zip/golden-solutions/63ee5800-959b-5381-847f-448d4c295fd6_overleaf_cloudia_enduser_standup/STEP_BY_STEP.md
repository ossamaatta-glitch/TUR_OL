# Step-by-step solution — Cloudia Enduser Standup

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/enduser.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/enduser.svg`](source/art/categories/enduser.svg). Save the file.
2. Create `art/glyphs/appwindow.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/appwindow.svg`](source/art/glyphs/appwindow.svg). Save the file.
3. Create `art/glyphs/browserlock.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/browserlock.svg`](source/art/glyphs/browserlock.svg). Save the file.
4. Create `art/glyphs/thinclient.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/thinclient.svg`](source/art/glyphs/thinclient.svg). Save the file.
5. Create `art/glyphs/vdi.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/vdi.svg`](source/art/glyphs/vdi.svg). Save the file.
6. Create `catalog/enduser/alcove.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/enduser/alcove.tex`](source/catalog/enduser/alcove.tex). Save the file.
7. Create `catalog/enduser/doorstep.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/enduser/doorstep.tex`](source/catalog/enduser/doorstep.tex). Save the file.
8. Create `catalog/enduser/enduser.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/enduser/enduser.tex`](source/catalog/enduser/enduser.tex). Save the file.
9. Create `catalog/enduser/transom.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/enduser/transom.tex`](source/catalog/enduser/transom.tex). Save the file.
10. Create `catalog/enduser/vestibule.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/enduser/vestibule.tex`](source/catalog/enduser/vestibule.tex). Save the file.
11. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.

## Finish

12. Compile the project and resolve any error caused by an incomplete edit.
13. Do not create these PDF derivatives by hand: `art/categories/enduser.pdf`, `art/glyphs/appwindow.pdf`, `art/glyphs/browserlock.pdf`, `art/glyphs/thinclient.pdf`, `art/glyphs/vdi.pdf`. They are generated or refreshed by the project build.
14. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
