# Solution guide — Cloudia Security Portfolio

**Task ID:** `f252b249-cfec-540f-aef1-ad91e84e276d_overleaf_cloudia_security_portfolio`  
**Startup profile:** `brief_in_documents`  
**Step budget:** `350`

## Objective

Category 07 is the largest in data/services.csv: identity for people, customers and workloads;
keys, secrets and certificates; defence at the edge and in the network; detection, audit and
compliance; and responders when it counts. The deck has none of it. Open the category and
reconcile every card against the registry row by row -- `make lint` reports each disagreement
separately, and the last two name mismatches shipped in a portfolio rather than on a page.

What has to land:

- the root deck inputs security after networking and above the appendix;
- the opener carries number 07, the registry's full name and the catSecurity accent;
- all twenty-two services appear as cards, reconciled to the registry, over at least three
  frames, since a frame stops at ten cards;
- a choosing frame compares the defences in a balanced price table.

The product pages are a separate piece of work; only the opener is graded here.

## Exact project changes

- `art/categories/security.pdf` — added (binary; compare hashes)
- `art/categories/security.svg` — added (30 patch lines)
- `art/glyphs/audit.pdf` — added (binary; compare hashes)
- `art/glyphs/audit.svg` — added (8 patch lines)
- `art/glyphs/badge.pdf` — added (binary; compare hashes)
- `art/glyphs/badge.svg` — added (9 patch lines)
- `art/glyphs/bot.pdf` — added (binary; compare hashes)
- `art/glyphs/bot.svg` — added (11 patch lines)
- `art/glyphs/bug.pdf` — added (binary; compare hashes)
- `art/glyphs/bug.svg` — added (9 patch lines)
- `art/glyphs/castle.pdf` — added (binary; compare hashes)
- `art/glyphs/castle.svg` — added (7 patch lines)
- `art/glyphs/certificate.pdf` — added (binary; compare hashes)
- `art/glyphs/certificate.svg` — added (9 patch lines)
- `art/glyphs/checklist.pdf` — added (binary; compare hashes)
- `art/glyphs/checklist.svg` — added (7 patch lines)
- `art/glyphs/deflect.pdf` — added (binary; compare hashes)
- `art/glyphs/deflect.svg` — added (7 patch lines)
- `art/glyphs/door.pdf` — added (binary; compare hashes)
- `art/glyphs/door.svg` — added (8 patch lines)
- `art/glyphs/enclave.pdf` — added (binary; compare hashes)
- `art/glyphs/enclave.svg` — added (9 patch lines)
- `art/glyphs/eye.pdf` — added (binary; compare hashes)
- `art/glyphs/eye.svg` — added (7 patch lines)
- `art/glyphs/filter.pdf` — added (binary; compare hashes)
- `art/glyphs/filter.svg` — added (6 patch lines)
- `art/glyphs/firewall.pdf` — added (binary; compare hashes)
- `art/glyphs/firewall.svg` — added (8 patch lines)
- `art/glyphs/logsearch.pdf` — added (binary; compare hashes)
- `art/glyphs/logsearch.svg` — added (8 patch lines)
- `art/glyphs/palisade.pdf` — added (binary; compare hashes)
- `art/glyphs/palisade.svg` — added (9 patch lines)
- `art/glyphs/people.pdf` — added (binary; compare hashes)
- `art/glyphs/people.svg` — added (9 patch lines)
- `art/glyphs/policy.pdf` — added (binary; compare hashes)
- `art/glyphs/policy.svg` — added (8 patch lines)
- `art/glyphs/posture.pdf` — added (binary; compare hashes)
- `art/glyphs/posture.svg` — added (7 patch lines)
- `art/glyphs/secret.pdf` — added (binary; compare hashes)
- `art/glyphs/secret.svg` — added (9 patch lines)
- `art/glyphs/signin.pdf` — added (binary; compare hashes)
- `art/glyphs/signin.svg` — added (8 patch lines)
- `art/glyphs/siren.pdf` — added (binary; compare hashes)
- `art/glyphs/siren.svg` — added (9 patch lines)
- `art/glyphs/vault.pdf` — added (binary; compare hashes)
- `art/glyphs/vault.svg` — added (9 patch lines)
- `catalog/security/beacon.tex` — added (76 patch lines)
- `catalog/security/bulwark.tex` — added (79 patch lines)
- `catalog/security/charter.tex` — added (78 patch lines)
- `catalog/security/cloister.tex` — added (78 patch lines)
- `catalog/security/coffer.tex` — added (77 patch lines)
- `catalog/security/covenant.tex` — added (75 patch lines)
- `catalog/security/docket.tex` — added (83 patch lines)
- `catalog/security/garrison.tex` — added (77 patch lines)
- `catalog/security/gatehouse.tex` — added (77 patch lines)
- `catalog/security/lanyard.tex` — added (78 patch lines)
- `catalog/security/palisade.tex` — added (80 patch lines)
- `catalog/security/picket.tex` — added (81 patch lines)
- `catalog/security/postern.tex` — added (73 patch lines)
- `catalog/security/rampart.tex` — added (80 patch lines)
- `catalog/security/roster.tex` — added (75 patch lines)
- `catalog/security/scarecrow.tex` — added (81 patch lines)
- `catalog/security/security.tex` — added (87 patch lines)
- `catalog/security/signet.tex` — added (80 patch lines)
- `catalog/security/tocsin.tex` — added (76 patch lines)
- `catalog/security/tumbler.tex` — added (93 patch lines)
- `catalog/security/turnstile.tex` — added (77 patch lines)
- `catalog/security/vigil.tex` — added (92 patch lines)
- `catalog/security/winnow.tex` — added (75 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)
- `data/reference-prices.csv` — modified (7 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
