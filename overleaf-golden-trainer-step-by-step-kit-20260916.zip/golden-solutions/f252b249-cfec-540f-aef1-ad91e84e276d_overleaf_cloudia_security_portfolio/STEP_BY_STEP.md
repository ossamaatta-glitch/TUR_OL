# Step-by-step solution — Cloudia Security Portfolio

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/security.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/security.svg`](source/art/categories/security.svg). Save the file.
2. Create `art/glyphs/audit.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/audit.svg`](source/art/glyphs/audit.svg). Save the file.
3. Create `art/glyphs/badge.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/badge.svg`](source/art/glyphs/badge.svg). Save the file.
4. Create `art/glyphs/bot.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/bot.svg`](source/art/glyphs/bot.svg). Save the file.
5. Create `art/glyphs/bug.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/bug.svg`](source/art/glyphs/bug.svg). Save the file.
6. Create `art/glyphs/castle.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/castle.svg`](source/art/glyphs/castle.svg). Save the file.
7. Create `art/glyphs/certificate.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/certificate.svg`](source/art/glyphs/certificate.svg). Save the file.
8. Create `art/glyphs/checklist.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/checklist.svg`](source/art/glyphs/checklist.svg). Save the file.
9. Create `art/glyphs/deflect.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/deflect.svg`](source/art/glyphs/deflect.svg). Save the file.
10. Create `art/glyphs/door.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/door.svg`](source/art/glyphs/door.svg). Save the file.
11. Create `art/glyphs/enclave.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/enclave.svg`](source/art/glyphs/enclave.svg). Save the file.
12. Create `art/glyphs/eye.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/eye.svg`](source/art/glyphs/eye.svg). Save the file.
13. Create `art/glyphs/filter.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/filter.svg`](source/art/glyphs/filter.svg). Save the file.
14. Create `art/glyphs/firewall.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/firewall.svg`](source/art/glyphs/firewall.svg). Save the file.
15. Create `art/glyphs/logsearch.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/logsearch.svg`](source/art/glyphs/logsearch.svg). Save the file.
16. Create `art/glyphs/palisade.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/palisade.svg`](source/art/glyphs/palisade.svg). Save the file.
17. Create `art/glyphs/people.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/people.svg`](source/art/glyphs/people.svg). Save the file.
18. Create `art/glyphs/policy.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/policy.svg`](source/art/glyphs/policy.svg). Save the file.
19. Create `art/glyphs/posture.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/posture.svg`](source/art/glyphs/posture.svg). Save the file.
20. Create `art/glyphs/secret.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/secret.svg`](source/art/glyphs/secret.svg). Save the file.
21. Create `art/glyphs/signin.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/signin.svg`](source/art/glyphs/signin.svg). Save the file.
22. Create `art/glyphs/siren.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/siren.svg`](source/art/glyphs/siren.svg). Save the file.
23. Create `art/glyphs/vault.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/vault.svg`](source/art/glyphs/vault.svg). Save the file.
24. Create `catalog/security/beacon.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/beacon.tex`](source/catalog/security/beacon.tex). Save the file.
25. Create `catalog/security/bulwark.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/bulwark.tex`](source/catalog/security/bulwark.tex). Save the file.
26. Create `catalog/security/charter.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/charter.tex`](source/catalog/security/charter.tex). Save the file.
27. Create `catalog/security/cloister.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/cloister.tex`](source/catalog/security/cloister.tex). Save the file.
28. Create `catalog/security/coffer.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/coffer.tex`](source/catalog/security/coffer.tex). Save the file.
29. Create `catalog/security/covenant.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/covenant.tex`](source/catalog/security/covenant.tex). Save the file.
30. Create `catalog/security/docket.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/docket.tex`](source/catalog/security/docket.tex). Save the file.
31. Create `catalog/security/garrison.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/garrison.tex`](source/catalog/security/garrison.tex). Save the file.
32. Create `catalog/security/gatehouse.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/gatehouse.tex`](source/catalog/security/gatehouse.tex). Save the file.
33. Create `catalog/security/lanyard.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/lanyard.tex`](source/catalog/security/lanyard.tex). Save the file.
34. Create `catalog/security/palisade.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/palisade.tex`](source/catalog/security/palisade.tex). Save the file.
35. Create `catalog/security/picket.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/picket.tex`](source/catalog/security/picket.tex). Save the file.
36. Create `catalog/security/postern.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/postern.tex`](source/catalog/security/postern.tex). Save the file.
37. Create `catalog/security/rampart.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/rampart.tex`](source/catalog/security/rampart.tex). Save the file.
38. Create `catalog/security/roster.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/roster.tex`](source/catalog/security/roster.tex). Save the file.
39. Create `catalog/security/scarecrow.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/scarecrow.tex`](source/catalog/security/scarecrow.tex). Save the file.
40. Create `catalog/security/security.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/security.tex`](source/catalog/security/security.tex). Save the file.
41. Create `catalog/security/signet.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/signet.tex`](source/catalog/security/signet.tex). Save the file.
42. Create `catalog/security/tocsin.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/tocsin.tex`](source/catalog/security/tocsin.tex). Save the file.
43. Create `catalog/security/tumbler.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/tumbler.tex`](source/catalog/security/tumbler.tex). Save the file.
44. Create `catalog/security/turnstile.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/turnstile.tex`](source/catalog/security/turnstile.tex). Save the file.
45. Create `catalog/security/vigil.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/vigil.tex`](source/catalog/security/vigil.tex). Save the file.
46. Create `catalog/security/winnow.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/security/winnow.tex`](source/catalog/security/winnow.tex). Save the file.
47. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.
48. Open `data/reference-prices.csv` in the Overleaf file tree, then replace the complete file contents
   with [`source/data/reference-prices.csv`](source/data/reference-prices.csv). Save the file.

## Finish

49. Compile the project and resolve any error caused by an incomplete edit.
50. Do not create these PDF derivatives by hand: `art/categories/security.pdf`, `art/glyphs/audit.pdf`, `art/glyphs/badge.pdf`, `art/glyphs/bot.pdf`, `art/glyphs/bug.pdf`, `art/glyphs/castle.pdf`, `art/glyphs/certificate.pdf`, `art/glyphs/checklist.pdf`, `art/glyphs/deflect.pdf`, `art/glyphs/door.pdf`, `art/glyphs/enclave.pdf`, `art/glyphs/eye.pdf`, `art/glyphs/filter.pdf`, `art/glyphs/firewall.pdf`, `art/glyphs/logsearch.pdf`, `art/glyphs/palisade.pdf`, `art/glyphs/people.pdf`, `art/glyphs/policy.pdf`, `art/glyphs/posture.pdf`, `art/glyphs/secret.pdf`, `art/glyphs/signin.pdf`, `art/glyphs/siren.pdf`, `art/glyphs/vault.pdf`. They are generated or refreshed by the project build.
51. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
