# Solution guide — Logic Course L14 Numerals To Fixpoint

**Task ID:** `b7a032d2-74a3-5123-80f6-c59053f09cda_overleaf_logic_course_l14_numerals_to_fixpoint`  
**Startup profile:** `prompt_only`  
**Step budget:** `350`

## Objective

Action the unactioned review note on the typeset notes for Lecture 14. The prep for this lecture
lists the terms and the order they have to be introduced in.

A reviewer left this note against the corollary labelled cor:CR in lectures/14-lambda-
calculus/lecture-notes.tex; nobody has actioned it:

Church-Rosser is done, so the notes can finally say what a lambda term computes. Please add, in
this order: Church numerals with the definition of lambda-definability (def:numerals) and the
iteration lemma (lem:iterate), then addition and multiplication (prop:arith); then booleans and
pairs (def:bool-pair, lem:bool-pair) and the predecessor (prop:pred), since that is what the
recursion scheme needs; then closure of the lambda-definable functions under composition and
primitive recursion (lem:pr-closure, items pc1-pc3) and the theorem that every primitive
recursive function is lambda-definable (thm:pr-lambda); and finally a section on fixed-point
combinators (prop:fixpoint, items fp1-fp2). Uniqueness of the value has to lean on the corollary
this note is attached to.

## Exact project changes

- `lectures/14-lambda-calculus/lecture-notes.tex` — modified (119 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
