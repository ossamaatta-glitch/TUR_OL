# Step-by-step solution — Cloudia Media Standup

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/media.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/media.svg`](source/art/categories/media.svg). Save the file.
2. Create `art/glyphs/adbreak.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/adbreak.svg`](source/art/glyphs/adbreak.svg). Save the file.
3. Create `art/glyphs/cctv.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/cctv.svg`](source/art/glyphs/cctv.svg). Save the file.
4. Create `art/glyphs/cloudplay.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/cloudplay.svg`](source/art/glyphs/cloudplay.svg). Save the file.
5. Create `art/glyphs/film.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/film.svg`](source/art/glyphs/film.svg). Save the file.
6. Create `art/glyphs/gamepad.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/gamepad.svg`](source/art/glyphs/gamepad.svg). Save the file.
7. Create `art/glyphs/live.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/live.svg`](source/art/glyphs/live.svg). Save the file.
8. Create `art/glyphs/livechat.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/livechat.svg`](source/art/glyphs/livechat.svg). Save the file.
9. Create `art/glyphs/packager.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/packager.svg`](source/art/glyphs/packager.svg). Save the file.
10. Create `art/glyphs/spotlight.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/spotlight.svg`](source/art/glyphs/spotlight.svg). Save the file.
11. Create `art/glyphs/transport.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/transport.svg`](source/art/glyphs/transport.svg). Save the file.
12. Create `catalog/media/cue.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/cue.tex`](source/catalog/media/cue.tex). Save the file.
13. Create `catalog/media/encore.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/encore.tex`](source/catalog/media/encore.tex). Save the file.
14. Create `catalog/media/gantry.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/gantry.tex`](source/catalog/media/gantry.tex). Save the file.
15. Create `catalog/media/intermission.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/intermission.tex`](source/catalog/media/intermission.tex). Save the file.
16. Create `catalog/media/klieg.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/klieg.tex`](source/catalog/media/klieg.tex). Save the file.
17. Create `catalog/media/marquee.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/marquee.tex`](source/catalog/media/marquee.tex). Save the file.
18. Create `catalog/media/matinee.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/matinee.tex`](source/catalog/media/matinee.tex). Save the file.
19. Create `catalog/media/media.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/media.tex`](source/catalog/media/media.tex). Save the file.
20. Create `catalog/media/montage.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/montage.tex`](source/catalog/media/montage.tex). Save the file.
21. Create `catalog/media/sprocket.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/sprocket.tex`](source/catalog/media/sprocket.tex). Save the file.
22. Create `catalog/media/tourney.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/media/tourney.tex`](source/catalog/media/tourney.tex). Save the file.
23. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.

## Finish

24. Compile the project and resolve any error caused by an incomplete edit.
25. Do not create these PDF derivatives by hand: `art/categories/media.pdf`, `art/glyphs/adbreak.pdf`, `art/glyphs/cctv.pdf`, `art/glyphs/cloudplay.pdf`, `art/glyphs/film.pdf`, `art/glyphs/gamepad.pdf`, `art/glyphs/live.pdf`, `art/glyphs/livechat.pdf`, `art/glyphs/packager.pdf`, `art/glyphs/spotlight.pdf`, `art/glyphs/transport.pdf`. They are generated or refreshed by the project build.
26. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
