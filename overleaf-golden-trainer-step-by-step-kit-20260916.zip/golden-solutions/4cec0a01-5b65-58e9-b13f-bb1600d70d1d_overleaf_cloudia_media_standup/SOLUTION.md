# Solution guide — Cloudia Media Standup

**Task ID:** `4cec0a01-5b65-58e9-b13f-bb1600d70d1d_overleaf_cloudia_media_standup`  
**Startup profile:** `brief_in_documents`  
**Step budget:** `350`

## Objective

Category 16 -- transcoding, live encoding, transport, packaging, ad insertion, interactive
streaming, camera streams, rendering, game servers and game streaming -- has ten rows in
data/services.csv and no pages. Build it from templates/category.tex and
templates/product.tex.

What has to land:

- the root deck inputs media after hybrid and above the appendix;
- the opener carries number 16, the catMedia accent and ten services, in two frames:
  pipelines, then cameras, rendering and games;
- the transcoding page exists, keyed from the registry;
- the game-streaming page braces its comma-bearing descriptor so the key parser reads it
  whole: \clProduct splits keys on any comma outside braces, and the unbraced form shifts the
  keys after it by one, which has printed a SKU chip carrying half a descriptor;
- all ten pages are inputted, the render-farm page a colleague pushes included.

## Exact project changes

- `art/categories/media.pdf` — added (binary; compare hashes)
- `art/categories/media.svg` — added (28 patch lines)
- `art/glyphs/adbreak.pdf` — added (binary; compare hashes)
- `art/glyphs/adbreak.svg` — added (7 patch lines)
- `art/glyphs/cctv.pdf` — added (binary; compare hashes)
- `art/glyphs/cctv.svg` — added (8 patch lines)
- `art/glyphs/cloudplay.pdf` — added (binary; compare hashes)
- `art/glyphs/cloudplay.svg` — added (7 patch lines)
- `art/glyphs/film.pdf` — added (binary; compare hashes)
- `art/glyphs/film.svg` — added (8 patch lines)
- `art/glyphs/gamepad.pdf` — added (binary; compare hashes)
- `art/glyphs/gamepad.svg` — added (9 patch lines)
- `art/glyphs/live.pdf` — added (binary; compare hashes)
- `art/glyphs/live.svg` — added (8 patch lines)
- `art/glyphs/livechat.pdf` — added (binary; compare hashes)
- `art/glyphs/livechat.svg` — added (7 patch lines)
- `art/glyphs/packager.pdf` — added (binary; compare hashes)
- `art/glyphs/packager.svg` — added (7 patch lines)
- `art/glyphs/spotlight.pdf` — added (binary; compare hashes)
- `art/glyphs/spotlight.svg` — added (7 patch lines)
- `art/glyphs/transport.pdf` — added (binary; compare hashes)
- `art/glyphs/transport.svg` — added (9 patch lines)
- `catalog/media/cue.tex` — added (76 patch lines)
- `catalog/media/encore.tex` — added (81 patch lines)
- `catalog/media/gantry.tex` — added (79 patch lines)
- `catalog/media/intermission.tex` — added (78 patch lines)
- `catalog/media/klieg.tex` — added (83 patch lines)
- `catalog/media/marquee.tex` — added (76 patch lines)
- `catalog/media/matinee.tex` — added (80 patch lines)
- `catalog/media/media.tex` — added (55 patch lines)
- `catalog/media/montage.tex` — added (80 patch lines)
- `catalog/media/sprocket.tex` — added (81 patch lines)
- `catalog/media/tourney.tex` — added (81 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
