# Step-by-step solution — Cloudia Iot Zenith Footprint

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/iot.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/iot.svg`](source/art/categories/iot.svg). Save the file.
2. Create `art/glyphs/antenna.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/antenna.svg`](source/art/glyphs/antenna.svg). Save the file.
3. Create `art/glyphs/car.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/car.svg`](source/art/glyphs/car.svg). Save the file.
4. Create `art/glyphs/colony.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/colony.svg`](source/art/glyphs/colony.svg). Save the file.
5. Create `art/glyphs/devicesecurity.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/devicesecurity.svg`](source/art/glyphs/devicesecurity.svg). Save the file.
6. Create `art/glyphs/edge.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/edge.svg`](source/art/glyphs/edge.svg). Save the file.
7. Create `art/glyphs/factory.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/factory.svg`](source/art/glyphs/factory.svg). Save the file.
8. Create `art/glyphs/provision.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/provision.svg`](source/art/glyphs/provision.svg). Save the file.
9. Create `art/glyphs/satellite.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/satellite.svg`](source/art/glyphs/satellite.svg). Save the file.
10. Create `art/glyphs/twin.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/twin.svg`](source/art/glyphs/twin.svg). Save the file.
11. Create `catalog/iot/chrysalis.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/chrysalis.tex`](source/catalog/iot/chrysalis.tex). Save the file.
12. Create `catalog/iot/cicada.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/cicada.tex`](source/catalog/iot/cicada.tex). Save the file.
13. Create `catalog/iot/colony.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/colony.tex`](source/catalog/iot/colony.tex). Save the file.
14. Create `catalog/iot/convoy.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/convoy.tex`](source/catalog/iot/convoy.tex). Save the file.
15. Create `catalog/iot/hatchery.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/hatchery.tex`](source/catalog/iot/hatchery.tex). Save the file.
16. Create `catalog/iot/iot.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/iot.tex`](source/catalog/iot/iot.tex). Save the file.
17. Create `catalog/iot/katydid.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/katydid.tex`](source/catalog/iot/katydid.tex). Save the file.
18. Create `catalog/iot/mantis.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/mantis.tex`](source/catalog/iot/mantis.tex). Save the file.
19. Create `catalog/iot/weir.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/weir.tex`](source/catalog/iot/weir.tex). Save the file.
20. Create `catalog/iot/zenith.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/iot/zenith.tex`](source/catalog/iot/zenith.tex). Save the file.
21. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.
22. Open `data/footprint.csv` in the Overleaf file tree, then replace the complete file contents
   with [`source/data/footprint.csv`](source/data/footprint.csv). Save the file.

## Finish

23. Compile the project and resolve any error caused by an incomplete edit.
24. Do not create these PDF derivatives by hand: `art/categories/iot.pdf`, `art/glyphs/antenna.pdf`, `art/glyphs/car.pdf`, `art/glyphs/colony.pdf`, `art/glyphs/devicesecurity.pdf`, `art/glyphs/edge.pdf`, `art/glyphs/factory.pdf`, `art/glyphs/provision.pdf`, `art/glyphs/satellite.pdf`, `art/glyphs/twin.pdf`. They are generated or refreshed by the project build.
25. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
