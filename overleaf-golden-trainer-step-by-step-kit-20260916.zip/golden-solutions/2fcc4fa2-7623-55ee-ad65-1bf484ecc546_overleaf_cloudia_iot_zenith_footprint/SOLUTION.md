# Solution guide — Cloudia Iot Zenith Footprint

**Task ID:** `2fcc4fa2-7623-55ee-ad65-1bf484ecc546_overleaf_cloudia_iot_zenith_footprint`  
**Startup profile:** `brief_in_documents`  
**Step budget:** `350`

## Objective

Category 14 -- the hub, provisioning, device security, the edge runtime, LoRaWAN, twins,
industrial data, vehicles and the ground stations -- has nine rows in data/services.csv and no
pages. Build it from templates/category.tex and templates/product.tex.

What has to land:

- the root deck inputs iot after management and above the appendix;
- the opener carries number 14, the registry name and accent, and nine services in two frames,
  grouped as connect-and-manage then model-and-ingest rather than one row of nine;
- the IoT hub page exists, keyed from the registry;
- the ground-station page states the 12-site footprint in both the lede and the highlight:
  nothing else in the deck quotes that estate, so a vague page has no second source to check
  it against;
- all nine pages are inputted, the LoRaWAN page a colleague pushes included.

## Exact project changes

- `art/categories/iot.pdf` — added (binary; compare hashes)
- `art/categories/iot.svg` — added (36 patch lines)
- `art/glyphs/antenna.pdf` — added (binary; compare hashes)
- `art/glyphs/antenna.svg` — added (9 patch lines)
- `art/glyphs/car.pdf` — added (binary; compare hashes)
- `art/glyphs/car.svg` — added (9 patch lines)
- `art/glyphs/colony.pdf` — added (binary; compare hashes)
- `art/glyphs/colony.svg` — added (9 patch lines)
- `art/glyphs/devicesecurity.pdf` — added (binary; compare hashes)
- `art/glyphs/devicesecurity.svg` — added (7 patch lines)
- `art/glyphs/edge.pdf` — added (binary; compare hashes)
- `art/glyphs/edge.svg` — added (7 patch lines)
- `art/glyphs/factory.pdf` — added (binary; compare hashes)
- `art/glyphs/factory.svg` — added (7 patch lines)
- `art/glyphs/provision.pdf` — added (binary; compare hashes)
- `art/glyphs/provision.svg` — added (8 patch lines)
- `art/glyphs/satellite.pdf` — added (binary; compare hashes)
- `art/glyphs/satellite.svg` — added (9 patch lines)
- `art/glyphs/twin.pdf` — added (binary; compare hashes)
- `art/glyphs/twin.svg` — added (8 patch lines)
- `catalog/iot/chrysalis.tex` — added (75 patch lines)
- `catalog/iot/cicada.tex` — added (73 patch lines)
- `catalog/iot/colony.tex` — added (78 patch lines)
- `catalog/iot/convoy.tex` — added (74 patch lines)
- `catalog/iot/hatchery.tex` — added (77 patch lines)
- `catalog/iot/iot.tex` — added (53 patch lines)
- `catalog/iot/katydid.tex` — added (77 patch lines)
- `catalog/iot/mantis.tex` — added (76 patch lines)
- `catalog/iot/weir.tex` — added (81 patch lines)
- `catalog/iot/zenith.tex` — added (73 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)
- `data/footprint.csv` — modified (7 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
