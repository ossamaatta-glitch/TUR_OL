# Solution guide — Logic Course L06 Reducibility To Fixed Point

**Task ID:** `078a1547-e3e5-5e91-8842-64bfec032f19_overleaf_logic_course_l06_reducibility_to_fixed_point`  
**Startup profile:** `prompt_only`  
**Step budget:** `350`

## Objective

Action the unactioned review note on the Lecture 6 typeset notes.

A reviewer left this note against the corollary labelled cor:not-ce in
lectures/06-computability-theory/lecture-notes.tex; nobody has actioned it:

The complement result above is the last thing we can say without reductions, so please add them:
many-one reducibility with its four basic facts as items rd1-rd4 (def:reduce, prop:reduce) and
m-completeness (def:complete, thm:complete); then that neither the set of total indices nor its
complement is c.e. (thm:tot), which is where the corollary this note hangs on gets used; then
Rice's theorem for index sets (def:indexset, thm:rice, cor:rice); and then the fixed-point
theorem in both of its equivalent forms (lem:fixed-equiv with items fx1 and fx2, thm:fixed).
Each of the last three has to reduce to the halting set through the reducibility facts rather
than by a fresh diagonal argument.

## Exact project changes

- `lectures/06-computability-theory/lecture-notes.tex` — modified (163 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
