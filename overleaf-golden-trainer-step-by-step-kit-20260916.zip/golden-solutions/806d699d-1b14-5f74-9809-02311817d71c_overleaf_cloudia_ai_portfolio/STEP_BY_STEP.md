# Step-by-step solution — Cloudia Ai Portfolio

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/ai.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/ai.svg`](source/art/categories/ai.svg). Save the file.
2. Create `art/glyphs/agent.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/agent.svg`](source/art/glyphs/agent.svg). Save the file.
3. Create `art/glyphs/bbox.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/bbox.svg`](source/art/glyphs/bbox.svg). Save the file.
4. Create `art/glyphs/bubble.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/bubble.svg`](source/art/glyphs/bubble.svg). Save the file.
5. Create `art/glyphs/cluster.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/cluster.svg`](source/art/glyphs/cluster.svg). Save the file.
6. Create `art/glyphs/compare.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/compare.svg`](source/art/glyphs/compare.svg). Save the file.
7. Create `art/glyphs/cube.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/cube.svg`](source/art/glyphs/cube.svg). Save the file.
8. Create `art/glyphs/docscan.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/docscan.svg`](source/art/glyphs/docscan.svg). Save the file.
9. Create `art/glyphs/flask.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/flask.svg`](source/art/glyphs/flask.svg). Save the file.
10. Create `art/glyphs/guardrail.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/guardrail.svg`](source/art/glyphs/guardrail.svg). Save the file.
11. Create `art/glyphs/medical.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/medical.svg`](source/art/glyphs/medical.svg). Save the file.
12. Create `art/glyphs/mic.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/mic.svg`](source/art/glyphs/mic.svg). Save the file.
13. Create `art/glyphs/searchdoc.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/searchdoc.svg`](source/art/glyphs/searchdoc.svg). Save the file.
14. Create `art/glyphs/sparkle.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/sparkle.svg`](source/art/glyphs/sparkle.svg). Save the file.
15. Create `art/glyphs/star.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/star.svg`](source/art/glyphs/star.svg). Save the file.
16. Create `art/glyphs/translate.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/translate.svg`](source/art/glyphs/translate.svg). Save the file.
17. Create `art/glyphs/vector.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/vector.svg`](source/art/glyphs/vector.svg). Save the file.
18. Create `art/glyphs/video.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/video.svg`](source/art/glyphs/video.svg). Save the file.
19. Create `art/glyphs/vision.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/vision.svg`](source/art/glyphs/vision.svg). Save the file.
20. Create `catalog/ai/ai.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/ai.tex`](source/catalog/ai/ai.tex). Save the file.
21. Create `catalog/ai/albatross.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/albatross.tex`](source/catalog/ai/albatross.tex). Save the file.
22. Create `catalog/ai/atelier.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/atelier.tex`](source/catalog/ai/atelier.tex). Save the file.
23. Create `catalog/ai/aviary.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/aviary.tex`](source/catalog/ai/aviary.tex). Save the file.
24. Create `catalog/ai/corvid.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/corvid.tex`](source/catalog/ai/corvid.tex). Save the file.
25. Create `catalog/ai/finch.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/finch.tex`](source/catalog/ai/finch.tex). Save the file.
26. Create `catalog/ai/hedgerow.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/hedgerow.tex`](source/catalog/ai/hedgerow.tex). Save the file.
27. Create `catalog/ai/heron.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/heron.tex`](source/catalog/ai/heron.tex). Save the file.
28. Create `catalog/ai/kestrel.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/kestrel.tex`](source/catalog/ai/kestrel.tex). Save the file.
29. Create `catalog/ai/lark.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/lark.tex`](source/catalog/ai/lark.tex). Save the file.
30. Create `catalog/ai/murmuration.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/murmuration.tex`](source/catalog/ai/murmuration.tex). Save the file.
31. Create `catalog/ai/nightingale.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/nightingale.tex`](source/catalog/ai/nightingale.tex). Save the file.
32. Create `catalog/ai/osprey.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/osprey.tex`](source/catalog/ai/osprey.tex). Save the file.
33. Create `catalog/ai/sandpiper.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/sandpiper.tex`](source/catalog/ai/sandpiper.tex). Save the file.
34. Create `catalog/ai/sparrow.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/sparrow.tex`](source/catalog/ai/sparrow.tex). Save the file.
35. Create `catalog/ai/stork.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/stork.tex`](source/catalog/ai/stork.tex). Save the file.
36. Create `catalog/ai/tern.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/tern.tex`](source/catalog/ai/tern.tex). Save the file.
37. Create `catalog/ai/vireo.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/vireo.tex`](source/catalog/ai/vireo.tex). Save the file.
38. Create `catalog/ai/wren.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/ai/wren.tex`](source/catalog/ai/wren.tex). Save the file.
39. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.
40. Open `data/discounts.csv` in the Overleaf file tree, then replace the complete file contents
   with [`source/data/discounts.csv`](source/data/discounts.csv). Save the file.

## Finish

41. Compile the project and resolve any error caused by an incomplete edit.
42. Do not create these PDF derivatives by hand: `art/categories/ai.pdf`, `art/glyphs/agent.pdf`, `art/glyphs/bbox.pdf`, `art/glyphs/bubble.pdf`, `art/glyphs/cluster.pdf`, `art/glyphs/compare.pdf`, `art/glyphs/cube.pdf`, `art/glyphs/docscan.pdf`, `art/glyphs/flask.pdf`, `art/glyphs/guardrail.pdf`, `art/glyphs/medical.pdf`, `art/glyphs/mic.pdf`, `art/glyphs/searchdoc.pdf`, `art/glyphs/sparkle.pdf`, `art/glyphs/star.pdf`, `art/glyphs/translate.pdf`, `art/glyphs/vector.pdf`, `art/glyphs/video.pdf`, `art/glyphs/vision.pdf`. They are generated or refreshed by the project build.
43. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
