# Solution guide — Cloudia Ai Portfolio

**Task ID:** `806d699d-1b14-5f74-9809-02311817d71c_overleaf_cloudia_ai_portfolio`  
**Startup profile:** `brief_in_documents`  
**Step budget:** `350`

## Objective

Category 09 has eighteen rows in data/services.csv -- the model hub and foundation models,
agents and evaluation, content safety, the ML platform, training clusters, labelling and
vector search, then the ready-made APIs for search, vision, video, speech, translation,
documents, text, health and recommendations -- and the deck has none of them. Open the
category.

What has to land:

- the root deck inputs ai after analytics and above the appendix;
- the opener carries the registry's ampersand name, the catAi accent and eighteen services;
- all eighteen services appear as cards over two frames, with exactly the two previews marked:
  the agent runtime and the evaluation service are the previews, and nothing else is;
- a choosing frame compares the ways to get a model in a balanced price table.

## Exact project changes

- `art/categories/ai.pdf` — added (binary; compare hashes)
- `art/categories/ai.svg` — added (43 patch lines)
- `art/glyphs/agent.pdf` — added (binary; compare hashes)
- `art/glyphs/agent.svg` — added (9 patch lines)
- `art/glyphs/bbox.pdf` — added (binary; compare hashes)
- `art/glyphs/bbox.svg` — added (7 patch lines)
- `art/glyphs/bubble.pdf` — added (binary; compare hashes)
- `art/glyphs/bubble.svg` — added (7 patch lines)
- `art/glyphs/cluster.pdf` — added (binary; compare hashes)
- `art/glyphs/cluster.svg` — added (9 patch lines)
- `art/glyphs/compare.pdf` — added (binary; compare hashes)
- `art/glyphs/compare.svg` — added (9 patch lines)
- `art/glyphs/cube.pdf` — added (binary; compare hashes)
- `art/glyphs/cube.svg` — added (7 patch lines)
- `art/glyphs/docscan.pdf` — added (binary; compare hashes)
- `art/glyphs/docscan.svg` — added (8 patch lines)
- `art/glyphs/flask.pdf` — added (binary; compare hashes)
- `art/glyphs/flask.svg` — added (8 patch lines)
- `art/glyphs/guardrail.pdf` — added (binary; compare hashes)
- `art/glyphs/guardrail.svg` — added (8 patch lines)
- `art/glyphs/medical.pdf` — added (binary; compare hashes)
- `art/glyphs/medical.svg` — added (7 patch lines)
- `art/glyphs/mic.pdf` — added (binary; compare hashes)
- `art/glyphs/mic.svg` — added (8 patch lines)
- `art/glyphs/searchdoc.pdf` — added (binary; compare hashes)
- `art/glyphs/searchdoc.svg` — added (9 patch lines)
- `art/glyphs/sparkle.pdf` — added (binary; compare hashes)
- `art/glyphs/sparkle.svg` — added (7 patch lines)
- `art/glyphs/star.pdf` — added (binary; compare hashes)
- `art/glyphs/star.svg` — added (6 patch lines)
- `art/glyphs/translate.pdf` — added (binary; compare hashes)
- `art/glyphs/translate.svg` — added (9 patch lines)
- `art/glyphs/vector.pdf` — added (binary; compare hashes)
- `art/glyphs/vector.svg` — added (9 patch lines)
- `art/glyphs/video.pdf` — added (binary; compare hashes)
- `art/glyphs/video.svg` — added (7 patch lines)
- `art/glyphs/vision.pdf` — added (binary; compare hashes)
- `art/glyphs/vision.svg` — added (8 patch lines)
- `catalog/ai/ai.tex` — added (71 patch lines)
- `catalog/ai/albatross.tex` — added (75 patch lines)
- `catalog/ai/atelier.tex` — added (94 patch lines)
- `catalog/ai/aviary.tex` — added (90 patch lines)
- `catalog/ai/corvid.tex` — added (78 patch lines)
- `catalog/ai/finch.tex` — added (79 patch lines)
- `catalog/ai/hedgerow.tex` — added (79 patch lines)
- `catalog/ai/heron.tex` — added (77 patch lines)
- `catalog/ai/kestrel.tex` — added (78 patch lines)
- `catalog/ai/lark.tex` — added (92 patch lines)
- `catalog/ai/murmuration.tex` — added (77 patch lines)
- `catalog/ai/nightingale.tex` — added (77 patch lines)
- `catalog/ai/osprey.tex` — added (77 patch lines)
- `catalog/ai/sandpiper.tex` — added (80 patch lines)
- `catalog/ai/sparrow.tex` — added (76 patch lines)
- `catalog/ai/stork.tex` — added (82 patch lines)
- `catalog/ai/tern.tex` — added (76 patch lines)
- `catalog/ai/vireo.tex` — added (90 patch lines)
- `catalog/ai/wren.tex` — added (81 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)
- `data/discounts.csv` — modified (8 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
