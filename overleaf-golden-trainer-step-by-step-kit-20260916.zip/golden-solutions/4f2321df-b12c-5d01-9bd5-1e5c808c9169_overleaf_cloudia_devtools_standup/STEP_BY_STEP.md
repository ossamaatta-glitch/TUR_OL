# Step-by-step solution — Cloudia Devtools Standup

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/devtools.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/devtools.svg`](source/art/categories/devtools.svg). Save the file.
2. Create `art/glyphs/blueprint.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/blueprint.svg`](source/art/glyphs/blueprint.svg). Save the file.
3. Create `art/glyphs/branch.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/branch.svg`](source/art/glyphs/branch.svg). Save the file.
4. Create `art/glyphs/chaos.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/chaos.svg`](source/art/glyphs/chaos.svg). Save the file.
5. Create `art/glyphs/codeassist.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/codeassist.svg`](source/art/glyphs/codeassist.svg). Save the file.
6. Create `art/glyphs/flame.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/flame.svg`](source/art/glyphs/flame.svg). Save the file.
7. Create `art/glyphs/hammer.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/hammer.svg`](source/art/glyphs/hammer.svg). Save the file.
8. Create `art/glyphs/load.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/load.svg`](source/art/glyphs/load.svg). Save the file.
9. Create `art/glyphs/package.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/package.svg`](source/art/glyphs/package.svg). Save the file.
10. Create `art/glyphs/pipeline.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/pipeline.svg`](source/art/glyphs/pipeline.svg). Save the file.
11. Create `art/glyphs/workstation.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/workstation.svg`](source/art/glyphs/workstation.svg). Save the file.
12. Create `catalog/devtools/caliper.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/caliper.tex`](source/catalog/devtools/caliper.tex). Save the file.
13. Create `catalog/devtools/crucible.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/crucible.tex`](source/catalog/devtools/crucible.tex). Save the file.
14. Create `catalog/devtools/devtools.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/devtools.tex`](source/catalog/devtools/devtools.tex). Save the file.
15. Create `catalog/devtools/draftboard.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/draftboard.tex`](source/catalog/devtools/draftboard.tex). Save the file.
16. Create `catalog/devtools/easel.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/easel.tex`](source/catalog/devtools/easel.tex). Save the file.
17. Create `catalog/devtools/magpie.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/magpie.tex`](source/catalog/devtools/magpie.tex). Save the file.
18. Create `catalog/devtools/quire.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/quire.tex`](source/catalog/devtools/quire.tex). Save the file.
19. Create `catalog/devtools/satchel.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/satchel.tex`](source/catalog/devtools/satchel.tex). Save the file.
20. Create `catalog/devtools/shell.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/shell.tex`](source/catalog/devtools/shell.tex). Save the file.
21. Create `catalog/devtools/spindle.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/spindle.tex`](source/catalog/devtools/spindle.tex). Save the file.
22. Create `catalog/devtools/tensile.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/tensile.tex`](source/catalog/devtools/tensile.tex). Save the file.
23. Create `catalog/devtools/treadle.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/devtools/treadle.tex`](source/catalog/devtools/treadle.tex). Save the file.
24. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.

## Finish

25. Compile the project and resolve any error caused by an incomplete edit.
26. Do not create these PDF derivatives by hand: `art/categories/devtools.pdf`, `art/glyphs/blueprint.pdf`, `art/glyphs/branch.pdf`, `art/glyphs/chaos.pdf`, `art/glyphs/codeassist.pdf`, `art/glyphs/flame.pdf`, `art/glyphs/hammer.pdf`, `art/glyphs/load.pdf`, `art/glyphs/package.pdf`, `art/glyphs/pipeline.pdf`, `art/glyphs/workstation.pdf`. They are generated or refreshed by the project build.
27. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
