# Solution guide — Cloudia Devtools Standup

**Task ID:** `4f2321df-b12c-5d01-9bd5-1e5c808c9169_overleaf_cloudia_devtools_standup`  
**Startup profile:** `brief_in_documents`  
**Step budget:** `350`

## Objective

Category 12 -- source, builds, pipelines, packages, infrastructure as code, the code
assistant, workstations, profiling, load testing, chaos and the shell -- has eleven rows in
data/services.csv and no pages.

What has to land:

- the root deck inputs devtools after webmobile and above the appendix;
- the opener carries number 12, the catDevtools accent, eleven services over two frames, since
  eleven cards is over the frame limit;
- the source-repository page exists, keyed from the registry;
- the shell page braces its comma-bearing descriptor so the key parser reads it whole: that
  descriptor has a comma in it, \clProduct splits keys on commas, and unbraced the keys after
  it shift by one and the SKU chip comes out wrong;
- all eleven pages are inputted, the chaos page a colleague pushes included.

## Exact project changes

- `art/categories/devtools.pdf` — added (binary; compare hashes)
- `art/categories/devtools.svg` — added (39 patch lines)
- `art/glyphs/blueprint.pdf` — added (binary; compare hashes)
- `art/glyphs/blueprint.svg` — added (8 patch lines)
- `art/glyphs/branch.pdf` — added (binary; compare hashes)
- `art/glyphs/branch.svg` — added (10 patch lines)
- `art/glyphs/chaos.pdf` — added (binary; compare hashes)
- `art/glyphs/chaos.svg` — added (7 patch lines)
- `art/glyphs/codeassist.pdf` — added (binary; compare hashes)
- `art/glyphs/codeassist.svg` — added (8 patch lines)
- `art/glyphs/flame.pdf` — added (binary; compare hashes)
- `art/glyphs/flame.svg` — added (9 patch lines)
- `art/glyphs/hammer.pdf` — added (binary; compare hashes)
- `art/glyphs/hammer.svg` — added (7 patch lines)
- `art/glyphs/load.pdf` — added (binary; compare hashes)
- `art/glyphs/load.svg` — added (7 patch lines)
- `art/glyphs/package.pdf` — added (binary; compare hashes)
- `art/glyphs/package.svg` — added (8 patch lines)
- `art/glyphs/pipeline.pdf` — added (binary; compare hashes)
- `art/glyphs/pipeline.svg` — added (9 patch lines)
- `art/glyphs/workstation.pdf` — added (binary; compare hashes)
- `art/glyphs/workstation.svg` — added (8 patch lines)
- `catalog/devtools/caliper.tex` — added (75 patch lines)
- `catalog/devtools/crucible.tex` — added (75 patch lines)
- `catalog/devtools/devtools.tex` — added (57 patch lines)
- `catalog/devtools/draftboard.tex` — added (78 patch lines)
- `catalog/devtools/easel.tex` — added (80 patch lines)
- `catalog/devtools/magpie.tex` — added (79 patch lines)
- `catalog/devtools/quire.tex` — added (78 patch lines)
- `catalog/devtools/satchel.tex` — added (75 patch lines)
- `catalog/devtools/shell.tex` — added (77 patch lines)
- `catalog/devtools/spindle.tex` — added (75 patch lines)
- `catalog/devtools/tensile.tex` — added (74 patch lines)
- `catalog/devtools/treadle.tex` — added (76 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
