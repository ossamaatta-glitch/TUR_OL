# Solution guide — Cloudia Containers Standup

**Task ID:** `65237749-4997-5c14-9c09-f55cf2f4a22e_overleaf_cloudia_containers_standup`  
**Startup profile:** `brief_open`  
**Step budget:** `350`

## Objective

Category 02 has had its seven services in data/services.csv since the registry landed, and
the deck still runs straight from Compute to the appendix. Stand the category up the way
Compute was built, from templates/category.tex and templates/product.tex. The registry is the
source of truth for every name, descriptor, SKU, status, scope and accent token, and
`make lint` checks each card and page against those rows.

What has to land:

- the root deck inputs the category, in registry order, above the appendix;
- the opener carries the registry number, name and accent, the service count and a card per
  service;
- the cluster service has its own product page, keyed from the registry;
- the fleet manager is a separate page and Global scope, as the registry says: people confuse
  the two, and only one of them is global;
- every service is inputted from the opener, including a page a colleague pushes while you
  work.

The other five product pages are being written by the rest of the team: put their input lines
in place, but do not write those pages yourself.

## Exact project changes

- `art/categories/containers.pdf` — added (binary; compare hashes)
- `art/categories/containers.svg` — added (48 patch lines)
- `art/glyphs/anchor.pdf` — added (binary; compare hashes)
- `art/glyphs/anchor.svg` — added (9 patch lines)
- `art/glyphs/backup.pdf` — added (binary; compare hashes)
- `art/glyphs/backup.svg` — added (9 patch lines)
- `art/glyphs/fleet.pdf` — added (binary; compare hashes)
- `art/glyphs/fleet.svg` — added (16 patch lines)
- `art/glyphs/mesh.pdf` — added (binary; compare hashes)
- `art/glyphs/mesh.svg` — added (11 patch lines)
- `art/glyphs/stack.pdf` — added (binary; compare hashes)
- `art/glyphs/stack.svg` — added (9 patch lines)
- `art/glyphs/wheel.pdf` — added (binary; compare hashes)
- `art/glyphs/wheel.svg` — added (9 patch lines)
- `catalog/containers/ballast.tex` — added (74 patch lines)
- `catalog/containers/berth.tex` — added (77 patch lines)
- `catalog/containers/containers.tex` — added (49 patch lines)
- `catalog/containers/hawser.tex` — added (70 patch lines)
- `catalog/containers/keelson-fleet.tex` — added (74 patch lines)
- `catalog/containers/keelson.tex` — added (95 patch lines)
- `catalog/containers/rigging.tex` — added (76 patch lines)
- `catalog/containers/wharf.tex` — added (76 patch lines)
- `cloudia-catalog.tex` — modified (10 patch lines)

Follow [STEP_BY_STEP.md](STEP_BY_STEP.md) for the ordered human-editing
checklist. The exact final source text is supplied under `source/`;
[solution.patch](solution.patch) is retained as a reference diff. Do
not upload or copy `golden_project.zip` into the project.

## Completion evidence

Finish the platform recording only after the changes are saved. QA
must run the native evaluator and accept this run only if it scores
1.0. [solution-evidence.json](solution-evidence.json) records the
source archive hashes and exact changed-path inventory.
