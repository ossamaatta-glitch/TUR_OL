# Step-by-step solution — Cloudia Containers Standup

Use this as an editor checklist. Complete every step manually in the
platform's visible Overleaf workspace; do not upload a project archive.

## Before editing

1. Start the assigned task from the platform and wait for its Overleaf project to load.
2. Read the task brief required by the startup profile shown in `SOLUTION.md`.
3. Keep this guide open outside the workspace. The files under `source/` contain
   the exact final text to paste; they do not perform any action for you.

## Editor steps

1. Create `art/categories/containers.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/categories/containers.svg`](source/art/categories/containers.svg). Save the file.
2. Create `art/glyphs/anchor.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/anchor.svg`](source/art/glyphs/anchor.svg). Save the file.
3. Create `art/glyphs/backup.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/backup.svg`](source/art/glyphs/backup.svg). Save the file.
4. Create `art/glyphs/fleet.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/fleet.svg`](source/art/glyphs/fleet.svg). Save the file.
5. Create `art/glyphs/mesh.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/mesh.svg`](source/art/glyphs/mesh.svg). Save the file.
6. Create `art/glyphs/stack.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/stack.svg`](source/art/glyphs/stack.svg). Save the file.
7. Create `art/glyphs/wheel.svg` in the Overleaf file tree, then paste the complete contents
   with [`source/art/glyphs/wheel.svg`](source/art/glyphs/wheel.svg). Save the file.
8. Create `catalog/containers/ballast.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/ballast.tex`](source/catalog/containers/ballast.tex). Save the file.
9. Create `catalog/containers/berth.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/berth.tex`](source/catalog/containers/berth.tex). Save the file.
10. Create `catalog/containers/containers.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/containers.tex`](source/catalog/containers/containers.tex). Save the file.
11. Create `catalog/containers/hawser.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/hawser.tex`](source/catalog/containers/hawser.tex). Save the file.
12. Create `catalog/containers/keelson-fleet.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/keelson-fleet.tex`](source/catalog/containers/keelson-fleet.tex). Save the file.
13. Create `catalog/containers/keelson.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/keelson.tex`](source/catalog/containers/keelson.tex). Save the file.
14. Create `catalog/containers/rigging.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/rigging.tex`](source/catalog/containers/rigging.tex). Save the file.
15. Create `catalog/containers/wharf.tex` in the Overleaf file tree, then paste the complete contents
   with [`source/catalog/containers/wharf.tex`](source/catalog/containers/wharf.tex). Save the file.
16. Open `cloudia-catalog.tex` in the Overleaf file tree, then replace the complete file contents
   with [`source/cloudia-catalog.tex`](source/cloudia-catalog.tex). Save the file.

## Finish

17. Compile the project and resolve any error caused by an incomplete edit.
18. Do not create these PDF derivatives by hand: `art/categories/containers.pdf`, `art/glyphs/anchor.pdf`, `art/glyphs/backup.pdf`, `art/glyphs/fleet.pdf`, `art/glyphs/mesh.pdf`, `art/glyphs/stack.pdf`, `art/glyphs/wheel.pdf`. They are generated or refreshed by the project build.
19. Save the final project and finish the platform recording. The native evaluator must return `1.0` for this to become a golden.
