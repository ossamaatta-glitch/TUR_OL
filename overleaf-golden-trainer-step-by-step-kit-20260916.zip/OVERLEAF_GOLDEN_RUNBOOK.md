# Overleaf golden-run key — ten-task cohort

## Purpose

This is the operating key for producing one legitimate, human-recorded golden
trajectory for each of the ten selected Overleaf tasks. A golden is not a
solution ZIP supplied to a trainer. It is a fresh platform recording in which
an assigned trainer completes the task through the Overleaf UI, followed by a
verified score and immutable artifact persistence.

The trainer receives the task through the normal platform queue plus a
coordinator-issued solution guide from
[golden-solutions/README.md](golden-solutions/README.md). The guide is derived
from the verified initial-to-golden project delta and states the required file
changes; the trainer must make those changes manually through the visible
Overleaf UI. They do not receive `golden_project.zip`, verifier implementation
details, platform service credentials, or a prerecorded action script.

## The cohort

The companion file [golden-assignment-register.csv](golden-assignment-register.csv)
contains the exact ten task IDs selected from rollout batch
`bc261169-62cd-46f9-8757-a667bfc7c2e2`. Every task is configured for a 350-step
budget and has:

```text
task.py
assets/initial_project.zip       # trainer starting state
assets/task_brief.pdf            # trainer-visible requirements
assets/golden_project.zip        # internal evaluator reference only
verifier/overleaf_eval.py        # internal evaluator only
```

The cohort includes one agent rollout that scored `1.0`
(`f252b249-..._overleaf_cloudia_security_portfolio`, rollout 2). That rollout
is useful diagnostic evidence but is **not** a human golden and must not be
relabeled or converted into one.

## Definition of a valid golden

A golden is valid only if all conditions below hold:

1. It is a real trainer-run platform recording, captured from the normal
   Overleaf desktop client. UI events, screenshots, action log, and milestone
   snapshots must all belong to that run.
2. It started against the task's currently imported `package_digest` and
   immutable `task_template_id`; these identities are copied from the run into
   the persisted golden record.
3. The task's Overleaf service is healthy, the initial project was seeded, and
   the trainer opened the correct project—not an external/local substitute.
4. The trainer completed the task through visible UI controls. No shell,
   filesystem API, direct service endpoint, hidden answer asset, prerecorded
   macro, or copied golden project is permitted.
5. The native Overleaf evaluator runs against the trainer output and returns a
   score of **1.0**. A score below 1.0 is a normal failed/partial delivery, not
   a golden candidate.
6. QA verifies the final document/project, the trace is plausible and
   complete, and accepts the delivery as the task's single golden.
7. The golden persistence job writes the immutable bundle and its manifest;
   the database reports `task_goldens.status = persisted`, a non-empty artifact
   URI, and a tree digest.

## What the trainer does

1. Open the task assigned by the platform; do not use a direct E2B/VNC URL.
2. Wait until the Overleaf project is loaded in the visible desktop.
3. Open the coordinator-issued solution guide for the assigned task, then make
   its required edits through the visible Overleaf UI.
   - The guide and its `solution.patch` explain what must change; they are
     reference material, not an executable action sequence.
   - `brief_in_documents`: open `Task Brief.pdf` from Documents before editing.
   - `brief_open`: use the brief already open in the desktop.
   - `prompt_only`: follow the full task text shown in the platform.
4. Work only in the visible Overleaf UI and save the resulting project.
5. Finish recording from the platform only after the work is complete.
6. Report completion to the golden coordinator. Do not download, upload, or
   request an answer file.

The task remains assigned to that trainer until QA either accepts it as the
golden or rejects it. A retry creates a new run; it never overwrites evidence
from an earlier run.

## What the coordinator / QA does

For each register row:

1. Before assignment, record the live platform `package_digest`,
   `task_template_id`, and evaluator digest in the register. Do not copy a
   hash from a local draft package; the platform's imported identity is the
   source of truth.
2. Confirm the task has a healthy paired Overleaf workspace on a smoke run:
   desktop connected, Overleaf service reached, initial project seeded, and
   correct task brief behavior for its startup profile.
3. Assign exactly one trainer to the row and set `assignment_status=assigned`.
4. On delivery, run the native evaluator against the human run's output and
   record the exact score and verifier report location.
5. Accept only score-1.0, trace-plausible deliveries. Reject incomplete,
   unrecorded, or identity-mismatched runs.
6. After acceptance, confirm golden persistence reached `persisted`; record
   the generated `golden_run_id`, `golden_artifact_uri`, and tree digest in the
   register.
7. Keep the persisted golden bundle internal. Trainers may receive task
   instructions and assignment status, never the output/answer portion of the
   bundle.

## Platform requirements

The platform already has most of the persistence path: accepting a delivery
claims one `task_goldens` row per task and launches the golden persistence job.
The job stores the run's action log, events, screenshots, artifacts, and
metadata under the golden artifact prefix while the database holds the digest
and lifecycle state.

Before using this cohort, the following must be true or added:

| Requirement | Why it matters | Required outcome |
| --- | --- | --- |
| Golden assignment flag/ACL | Prevents an unassigned trainer from claiming the only golden slot. | Only the named trainer can start the golden candidate run. |
| Pre-accept evaluation gate | The existing "Accepted" review path claims a golden; acceptance must not rely on human assertion alone. | The native evaluator score is persisted and must equal `1.0` before Golden Accept is enabled. |
| Run identity check | Packages/templates can change after import. | Candidate run package digest, evaluator digest, and template ID match the assignment record. |
| Overleaf readiness check | A visible desktop alone is not enough. | Service, seeded project, browser session, and brief opening behavior are confirmed. |
| Full capture | A final file without trace evidence is not a golden trajectory. | Actions, screenshots, events, final project/output, and ready snapshots exist. |
| One-golden constraint | A task must have one authoritative reference. | The existing unique `task_goldens(task_id)` claim remains enforced. |
| Persist completion check | A claim is not a usable deliverable. | `persisted` status, artifact URI, object count, and tree digest are present. |

The minimum implementation change is a dedicated **Assign golden** operation
and a **Accept as golden** operation. The latter must be server-side gated by
the run's evaluator result and pinned identities. It must not accept a client
supplied score or permit an admin to bypass evaluator evidence by editing the
UI request.

## Internal golden artifact contract

For each accepted task, preserve this internal-only bundle:

```text
golden/<task-id>/<golden-tree-digest>/
├── meta.json                 # task, package, template and evaluator identity
├── milestones.json
├── actions.jsonl             # real recorded UI actions
├── events.ndjson
├── screenshots/ or artifacts/
├── final-project/ or captured-output/
├── verifier-report.json
└── MANIFEST.sha256
```

The `golden_project.zip` in the source task package remains an evaluator input,
not a trainer artifact. It is never copied into the trainer-facing packet.

## Completion checklist

For all ten rows, completion means:

- [ ] Assigned trainer and live task identity recorded.
- [ ] Fresh workspace smoke test passes.
- [ ] Human UI recording completed.
- [ ] Native verifier score is 1.0 with report saved.
- [ ] QA accepted the run as plausible and complete.
- [ ] Golden job is `persisted`, with artifact URI and digest recorded.
- [ ] The task has exactly one persisted golden and no answer files were shared
      with trainers.
