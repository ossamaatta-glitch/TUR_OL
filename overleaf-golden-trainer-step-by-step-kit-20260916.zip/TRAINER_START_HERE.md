# Overleaf golden trainer kit

Use this kit only for the task ID assigned to you. It explains the required
solution; you must still create that solution yourself in the platform's
visible Overleaf workspace so the platform records a real trainer trajectory.

## Step-by-step workflow

1. In the platform, start your assigned Overleaf task. Do not open a direct
   E2B/VNC link and do not work in a local Overleaf project.
2. Wait for the project to finish loading in the embedded desktop. Confirm the
   task ID in the platform matches the directory name in `golden-solutions/`.
3. Read the task requirements in the expected place:
   - `prompt_only`: use the task prompt shown by the platform.
   - `brief_in_documents`: open `Task Brief.pdf` in Documents.
   - `brief_open`: use the already-open task brief.
4. Open `golden-solutions/<task-id>/STEP_BY_STEP.md`. It gives the ordered
   file-by-file editing steps for your exact task.
5. In the visible Overleaf editor, carry out each numbered instruction. When a
   step links to a file under `source/`, create/open the named file in Overleaf
   and paste the supplied complete text, then save it.
6. Save the project and compile it where compilation is supported. Resolve any
   compilation error caused by an incomplete patch application.
7. Recheck that every file listed in `SOLUTION.md` was changed. Do not upload
   a project archive, use an API, run a macro, or copy hidden answer files.
8. Finish the platform recording only after the saved project is complete.
   The coordinator will run the native evaluator; a golden is accepted only at
   a score of `1.0`.

## Kit layout

```text
golden-solutions/
  <task-id>/SOLUTION.md             # task-specific required changes
  <task-id>/solution.patch          # exact verified source delta
  <task-id>/solution-evidence.json  # hashes and changed-file inventory
```

The raw `golden_project.zip`, verifier source, and service credentials are
intentionally not in this kit. The solution guides are the approved reference
for the designated golden-trainer assignment; they are not an automation tool
or a prerecorded trajectory.
